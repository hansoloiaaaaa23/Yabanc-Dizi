version = 1
cloudstream {
    language = "tr"
    authors = listOf("seninAdın")
    status = 1
}
